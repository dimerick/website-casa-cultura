<?php $__env->startSection('title'); ?>
    Casa de la Cultura - Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

           <div class="header-page">
            <img src="<?php echo e(asset('assets/images/header-pages/blog.jpg')); ?>">
            <h1>BLOG</h1>
        </div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(".nav-sec").click(function () {
        $(".nav-sec").removeClass("active");
        $(this).addClass("active");
    });
</script>

    <script>
        $("#menu-programa").addClass("active");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>