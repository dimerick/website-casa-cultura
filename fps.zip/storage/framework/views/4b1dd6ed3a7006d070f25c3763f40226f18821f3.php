<?php $__env->startSection('title'); ?>
    Medellín Cup
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <!--Carousel Wrapper-->
    <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
        <!--Indicators-->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-2" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-2" data-slide-to="1"></li>
            <li data-target="#carousel-example-2" data-slide-to="2"></li>
            <li data-target="#carousel-example-2" data-slide-to="3"></li>
        </ol>
        <!--/.Indicators-->
        <!--Slides-->
        <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
                <div class="view hm-black-slight">
                    <img class="d-block w-100" src="<?php echo e(asset('assets/images/slider/slider1.jpg')); ?>" alt="First slide">
                    <div class="mask"></div>
                </div>
                <div class="carousel-caption">
                    <h3 class="h3-responsive">Participa en este gran evento deportivo</h3>
                    <p><a class="btn" href="#">Inscribe Tu Equipo</a></p>
                </div>
            </div>
            <div class="carousel-item">
                <!--Mask color-->
                <div class="view hm-black-slight">
                    <img class="d-block w-100" src="<?php echo e(asset('assets/images/slider/slider2.jpg')); ?>" alt="Second slide">
                    <div class="mask"></div>
                </div>
                <div class="carousel-caption">
                    <!--<h3 class="h3-responsive">¿Qué hacer en Medellín?</h3>-->
                    <!--<p><a class="btn" href="#">Ver más</a></p>-->
                </div>
            </div>

            <div class="carousel-item">
                <!--Mask color-->
                <div class="view hm-black-slight">
                    <img class="d-block w-100" src="<?php echo e(asset('assets/images/slider/slider3.jpg')); ?>" alt="Third slide">
                    <div class="mask"></div>
                </div>
                <div class="carousel-caption">
                    <!--<h3 class="h3-responsive">¿Qué hacer en Medellín?</h3>-->
                    <!--<p><a class="btn" href="#">Ver más</a></p>-->
                </div>
            </div>

            <div class="carousel-item">
                <!--Mask color-->
                <div class="view hm-black-slight">
                    <img class="d-block w-100" src="<?php echo e(asset('assets/images/slider/slider4.jpg')); ?>" alt="Four slide">
                    <div class="mask"></div>
                </div>
                <div class="carousel-caption">
                    <!--<h3 class="h3-responsive">¿Qué hacer en Medellín?</h3>-->
                    <!--<p><a class="btn" href="#">Ver más</a></p>-->
                </div>
            </div>

        </div>
        <!--/.Slides-->
        <!--Controls-->
        <a class="carousel-control-prev" href="#carousel-example-2" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel-example-2" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
        <!--/.Controls-->
    </div>
    <!--/.Carousel Wrapper-->


    <div class="container-fluid">
        <section class="item-main wow bounceInLeft" data-wow-delay="0.5s">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <h1 class="title-section">Medellín Cup</h1>
                    <hr class="hr-title">
                    <p class="">
                        La Medellín Cup, es un torneo internacional de fútbol base que se disputara en la Ciudad de Medellín –
                        Colombia donde aquí encontramos a una de las mejores canteras de la Región en lo que respecta al fútbol base
                        internacional se refiere.
                        Medellín Cup quiere posesionarse como un torneo de prestigio en el mundo del futbol Base. Donde encontraras
                        una mezcla de sensaciones, espectáculo, emoción, y pasión... Pero lo más importante e imprescindible, es que
                        la Medellín Cup, es una fiesta del fútbol formativo, que potencia y fomenta los valores del deporte dentro
                        de un marco competitivo.
                    </p>
                    <div class="content-center">
                    <a class="btn btn-success" href="#">Deseo Participar</a>
                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>

        </section>
    </div>






    <div class="container">
        <section class="item-main wow bounceInRight" data-wow-delay="0.5s">
            <div class="row">
                <div class="col-sm-12">
                    <h2 class="title-section">La Ciudad</h2>
                    <hr class="hr-title">
                    <div class="d-md-flex flex-row flex-md-wrap justify-content-md-between">
                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/plaza-botero.jpg')); ?>" onclick="openModal();currentSlide(1)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Plaza Botero</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/palacio-cultura.jpg')); ?>" onclick="openModal();currentSlide(2)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Palacio de la Cultura Rafael Uribe Uribe</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/parque-norte.jpg')); ?>" onclick="openModal();currentSlide(3)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Parque Norte</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/jardin-botanico.jpg')); ?>" onclick="openModal();currentSlide(4)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Jardín Botánico</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/parque-explora.jpg')); ?>" onclick="openModal();currentSlide(5)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Parque Explora</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/aeroparque.jpg')); ?>" onclick="openModal();currentSlide(6)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Aeroparque Juan Pablo II</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/pueblito-paisa.jpg')); ?>" onclick="openModal();currentSlide(7)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Cerro Nutibara o Pueblito Paisa</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/parque-arvi.jpg')); ?>" onclick="openModal();currentSlide(8)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Parque Ecoturístico Arví</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/unidad-deportivo.jpg')); ?>" onclick="openModal();currentSlide(9)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Unidad Deportiva Atanasio Girardot</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                        <div class="card">
                            <img class="card-img-top" src="<?php echo e(asset('assets/images/ciudad/metro-metro-cable.jpg')); ?>" onclick="openModal();currentSlide(10)"
                                 class="hover-shadow" alt="Card image cap">
                            <div class="card-body">
                                <h4 class="card-title">Metro y Metrocable De Medellín</h4>
                                <p class="card-text"></p>
                            </div>
                        </div>

                    </div>


                </div>
            </div>

        </section>
    </div>



    <!--Modal-->

    <div id="myModal" class="modal">
        <span class="close-modal cursor" onclick="closeModal()">&times;</span>


        <div class="modal-content">

            <div class="mySlides">
                <div class="numbertext">1 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/plaza-botero.jpg')); ?>" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext">2 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/palacio-cultura.jpg')); ?>" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext">3 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/parque-norte.jpg')); ?>" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext">4 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/jardin-botanico.jpg')); ?>" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext">5 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/parque-explora.jpg')); ?>" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext">6 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/aeroparque.jpg')); ?>" style="width:100%">
            </div>


            <div class="mySlides">
                <div class="numbertext">7 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/pueblito-paisa.jpg')); ?>" style="width:100%">
            </div>


            <div class="mySlides">
                <div class="numbertext">8 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/parque-arvi.jpg')); ?>" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext">9 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/unidad-deportivo.jpg')); ?>" style="width:100%">
            </div>

            <div class="mySlides">
                <div class="numbertext">10 / 10</div>
                <img src="<?php echo e(asset('assets/images/ciudad/metro-metro-cable.jpg')); ?>" style="width:100%">
            </div>

            <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
            <a class="next" onclick="plusSlides(1)">&#10095;</a>

            <div class="caption-container">
                <p id="caption"></p>
            </div>
            <div>
                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/plaza-botero.jpg')); ?>" onclick="currentSlide(1)" alt="
      <b>Plaza Botero</b>
      <p>La Plaza conocida también como Parque de las Esculturas, tiene una extensión de 7.500 metros cuadrados aproximadamente y está rodeada por el Museo de Antioquia y el Palacio de la Cultura Rafael Uribe Uribe, un paso obligado para visitar. Ubicado en el Centro de Medellín, sobre Carabobo. Contiene la mayor exhibición de esculturas al aire libre en el mundo del artista antioqueño Fernando Botero. Son 23 obras monumentales  que hacen de este lugar uno de los principales referentes de la ciudad y un ícono de la expresión artística.</p>
">
                </div>

                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/palacio-cultura.jpg')); ?>" onclick="currentSlide(2)" alt="
      <b>Palacio de la Cultura Rafael Uribe Uribe</b>
      <p>La majestuosidad de este edificio de estilo gótico neoclásico, diseñado y construido por el arquitecto belga Agustín Goovaerts entre 1929 y 1937, hace parte del conjunto cultural y patrimonial de Medellín.</p>

<p>En la actualidad es la sede del Instituto de Cultura y Patrimonio de Antioquia y alberga tesoros como el Archivo Histórico de Antioquia, la Fonoteca Departamental Hernán Restrepo Duque, el Centro de Documentación Musical, entre otros.</p>

<p>En la cúpula del Palacio se realizan actividades como “Cine en la cúpula”, una iniciativa del Instituto para fomentar la reflexión y el conocimiento a través del lenguaje cinematográfico.</p>
">
                </div>

                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/parque-norte.jpg')); ?>" onclick="currentSlide(3)" alt="
      <b>Parque Norte</b>
      <p>Único lugar de cielo abierto en la ciudad a, donde encontraras atracciones mecánicas vinculadas a la cultura y convivencia ciudadana, un lugar para disfrutar de experiencias extremas.</p>

<p>Este espacio ofrece a los habitantes y visitantes de la ciudad un total de 27 atracciones mecánicas distribuidas en cuatro plazoletas temáticas: Extrema, Aventura, Expedición y Fantasía. Adicionalmente cuenta con el lago urbano más grande de Latinoamérica en el que se pueden realizar actividades de avistamiento de aves.</p>

">
                </div>

                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/jardin-botanico.jpg')); ?>" onclick="currentSlide(4)" alt="
      <b>Jardín Botánico</b>
      <p>Es el pulmón verde más grande de la ciudad ubicado dentro del área urbana de Medellín, un museo vivo de 14 hectáreas de extensión, cuenta con más de 400 plantas, árboles, y más de 1.000 especies de fauna y flora de diversos ecosistemas, además sus visitantes podrán apreciar el Orquideorama José Jerónimo Triana estructura elaborada con madera cultivada que forma figuras hexagonales que semejan la unión de grandes pétalos o de panales.</p>

<p>Este refugio natural cuenta con colecciones de plantas ornamentales, colecciones temáticas y colecciones de conservación, todas con una clasificación sencilla para poder disfrutar y aprender con la diversidad y belleza de su flora. También es un excelente lugar para el descanso y el encuentro.</p>

">
                </div>

                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/parque-explora.jpg')); ?>" onclick="currentSlide(5)" alt="
      <b>Parque Explora</b>
      <p>Este parque ofrece a sus visitantes salas interactivas, auditorio para proyecciones en 3D, sala infantil y una sala de exposiciones temporales. Quienes lo recorren tienen la oportunidad de experimentar, de aprender divirtiéndose y de construir un conocimiento que posibilita el desarrollo y el bienestar de los habitantes y visitantes de Medellín.</p>
">
                </div>

                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/aeroparque.jpg')); ?>" onclick="currentSlide(6)" alt="
      <b>Aeroparque Juan Pablo II</b>
      <p>Es el parque acuático más grande de Medellín y su nombre es un homenaje a la visita que hizo el Papa Juan Pablo II a la ciudad en 1986,  actualmente cuenta con 17 hectáreas con amplias zonas verdes para el descanso y la recreación, 6 piscinas: olas, toboganes, semi olímpica, poleas, didáctica y una para niños, además de la pista múltiple en la que se puede caminar, trotar, patinar y montar en bicicleta.</p>
">
                </div>

                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/pueblito-paisa.jpg')); ?>" onclick="currentSlide(7)" alt="
      <b>Cerro Nutibara o Pueblito Paisa</b>
      <p>Es un espacio dedicado a los pueblos tradicionales de Antioquia convirtiéndose así en una réplica conmemorando la tradición paisa. Cuenta con una plaza en piedra, una fuente, una iglesia, una casa cural, la alcaldía, la barbería y la escuela que son característicos de los pueblos tradicionales.</p>

<p>Esta localizado en la cima del Cerro de Nutibara. El pueblito paisa cuenta con unos balcones que dan una vista maravillosa a la ciudad de Medellín de día y de noche.</p>

<p>Se pueden encontrar allí tiendas de artesanías tradicionales paisas así como: restaurantes de comida típica en donde los visitantes pueden involucrarse directamente con la cultura paisa que conmemora este lugar.</p>

<p>Se puede acceder a este por medio de automóvil o por una vía adecuada para deportistas y caminantes en donde se puede gozar de un espacio rico en naturaleza.</p>
">
                </div>

                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/parque-arvi.jpg')); ?>" onclick="currentSlide(8)" alt="
      <b>Parque Ecoturístico Arví</b>
      <p>Único parque en Colombia y tercer destino del país Certificado en Sostenibilidad. Un parque abierto con cerca de 2.000 hectáreas de bosques de niebla. El Parque Arví, cuenta con senderos ecológicos y prehispánicos llenos de historia y tradición, zonas de picnic y senderos, una importante hábitat de especies de flora y fauna como musgos, hongos, ranas, aves y mariposas.</p>
">
                </div>

                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/unidad-deportivo.jpg')); ?>" onclick="currentSlide(9)" alt="
      <b>Unidad Deportiva Atanasio Girardot</b>
      <p>Por su gran capacidad y solidez la unidad deportiva Atanasio Girardot no solamente es el lugar en donde se presencian momentos deportivos de gran importancia sino que también es aprovechado por la alcaldía y la ciudadanía de Medellín para otros eventos que implican grandes masas de personas como conciertos, entre otras actividades.</p>

">
                </div>

                <div class="column">
                    <img class="demo" src="<?php echo e(asset('assets/images/ciudad/metro-metro-cable.jpg')); ?>" onclick="currentSlide(10)" alt="
      <b>Metro y Metrocable De Medellín</b>
      <p>El Metro de Medellín es un sistema masivo de tránsito rápido que sirve a la ciudad de Medellín y el Valle de Aburra en Antioquia, Colombia.</p>

<p>Al hacer uso del metro de Medellín se puede también apreciar la ciudad desde una altura considerable, además de un transporte rápido y práctico es un atractivo turístico en donde se puede apreciar  una vista panorámica al pasar por los diferentes sectores de la ciudad de Medellín que cumple la ruta del metro.</p>
">
                </div>
            </div>



        </div>


    </div>

    <!--Modal-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $("#menu-inicio").addClass("active");
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>