<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title', 'Medellín Cup'); ?></title>
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('assets/css/font-awesome.css')); ?>" rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="<?php echo e(asset('assets/css/mdb.min.css')); ?>" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

    <!--Fonts-->
    <link href="https://fonts.googleapis.com/css?family=Boogaloo" rel="stylesheet">

    <?php echo $__env->yieldContent('css'); ?>

    <!--Favicon-->
    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('assets/favicon/apple-icon-57x57.png')); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('assets/favicon/apple-icon-60x60.png')); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('assets/favicon/apple-icon-72x72.png')); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('assets/favicon/apple-icon-76x76.png')); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('assets/favicon/apple-icon-114x114.png')); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('assets/favicon/apple-icon-120x120.png')); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('assets/favicon/apple-icon-144x144.png')); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('assets/favicon/apple-icon-152x152.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/favicon/apple-icon-180x180.png')); ?>">
    <link rel="icon" type="image/png" sizes="192x192" href="<?php echo e(asset('assets/favicon/android-icon-192x192.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/favicon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('assets/favicon/favicon-96x96.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/favicon/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/favicon/manifest.json')); ?>">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo e(asset('assets/favicon/ms-icon-144x144.png')); ?>">
    <meta name="theme-color" content="#ffffff">
</head>

<body>

<!-- Start your project here-->

<!--Main Navigation-->
<header>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="logo">
                    <a href="#"> <img src="<?php echo e(asset('assets/images/logo-horizontal.png')); ?>"></a>
                </div>

            </div>
            <div class="col-md-6">
                <div class="date-torneo">
                    <ul>
                        <li>Del 9 al 16 de Junio</li>
                        <li>I Edición</li>
                        <li> Medellín Colombia</li>
                    </ul>
                </div>

            </div>
        </div>

    </div>
</header>


<nav class="navbar navbar-expand-lg navbar-dark bg-default">
    <div class="container">
        <!--<a class="navbar-brand" href="#"></a>-->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li id="menu-inicio" class="nav-item">
                    <a class="nav-link" href="/">Inicio <span class="sr-only">(current)</span></a>
                </li>
                <!--<li class="nav-item submenu">-->
                <!--<a class="nav-link" href="#">Torneo <i class="fa fa-angle-down" aria-hidden="true"></i></a>-->
                <!--<ul>-->
                <!--<li>-->
                <!--<a class="nav-link" href="#">Misión<span class="sr-only">(current)</span></a>-->
                <!--</li>-->
                <!--<li>-->
                <!--<a class="nav-link" href="#">Visión<span class="sr-only">(current)</span></a>-->
                <!--</li>-->
                <!--</ul>-->
                <!--</li>-->
                <li id="menu-torneo" class="nav-item">
                    <a class="nav-link" href="/torneo">Torneo</a>
                </li>
                <li id="menu-categorias" class="nav-item">
                    <a class="nav-link" href="/categorias">Categorias</a>
                </li>
                <li id="menu-reglamento" class="nav-item">
                    <a class="nav-link" href="/reglamento">Reglamento</a>
                </li>
                <li id="menu-terminos" class="nav-item">
                    <a class="nav-link" href="/terminos-condiciones">Términos y Condiciones</a>
                </li>
                <li id="menu-programa" class="nav-item">
                    <a class="nav-link" href="/programa">Programa</a>
                </li>
                <li id="menu-alojamiento-trans" class="nav-item">
                    <a class="nav-link" href="/alojamiento-transporte">Alojamiento y Transporte</a>
                </li>
                <li id="menu-precios" class="nav-item">
                    <a class="nav-link" href="/precios">Precios</a>
                </li>
                <li id="menu-preguntas" class="nav-item">
                    <a class="nav-link" href="/preguntas-frecuentes">Preguntas Frecuentes</a>
                </li>
                <li id="menu-inscripcion" class="nav-item">
                    <a class="nav-link" href="/inscripcion">Inscripción</a>
                </li>

            </ul>
            <ul class="navbar-nav nav-flex-icons">
                <li class="nav-item">
                    <a class="nav-link"><i class="fa fa-facebook fa-2x"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"><i class="fa fa-twitter fa-2x"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link"><i class="fa fa-instagram fa-2x"></i></a>
                </li>
            </ul>
        </div>

    </div>
</nav>



<section class="main-section">
<?php echo $__env->yieldContent('main-content'); ?>

</section>



<!--Footer-->
<footer class="page-footer center-on-small-only unique-color-dark pt-0">

    <!--Footer Links-->
    <div class="container">
        <div class="row mt-3">

            <!--Fourth column-->
            <div class="col-md-12 align-content-center">
                <h6 class="title font-bold"><strong>Contacto</strong></h6>
                <p><i class="fa fa-home mr-3"></i> Cl 104 No.84C-19 - Medellín, Colombia</p>
                <p><i class="fa fa-envelope mr-3"></i> info@medellincup.com</p>
                <p><i class="fa fa-phone mr-3"></i> (+57) 312 224 05 49 </p>
                <p><i class="fa fa-phone mr-3"></i> (+57) 305 859 80 79 </p>
            </div>


        </div>
    </div>
    <!--/.Footer Links-->

    <!-- Copyright-->
    <div class="footer-copyright">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    Copyright © 2017 Medellín Cup. Desarrollado por <a href="#">Erick Sáenz</a>
                </div>
            </div>

        </div>
    </div>
    <!--/.Copyright -->

    <div class="go-top">
        <a href="#top"><i class="fa fa-angle-up fa-2x" aria-hidden="true"></i></a>
    </div>
</footer>


<!--/.Footer-->

<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-3.2.1.min.js')); ?>"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('assets/js/mdb.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/menu.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/general.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/modal-images.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>