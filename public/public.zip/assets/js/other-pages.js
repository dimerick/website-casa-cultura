$(".nav-sec").click(function () {
  $(".nav-sec").removeClass("active");
  $(this).addClass("active");
});

